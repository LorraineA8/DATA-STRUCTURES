catholic_martyrs = ["Achileo, Kiwanuka, Yowana, Mukiibi, Yusufu, Lugalama, Zakayo, Lubega, Adolphus, Ludigo, Mukasa, Ambrosius, Kibuuka, Anatoli, Kiriggwajjo, Andrew, Kaggwa, Antanansio, Bazzekuketta, Bruno, Sserunkuuma, Charles, Lwanga, Denis, Ssebuggwawo, Wasswa, Gonzaga, Gonza, Gyavira, Musoke, James, Buuzaabalyaawo, John, Maria, Muzeeyi, Joseph, Mukasa, Kizito, Lukka, Baanabakintu, Matiya, Mulumba, Mbaga, Tuzinde, Mugagga, Lubowa, Mukasa, Kiriwawanvu, Nowa, Mawaggali, Ponsiano, Ngondwe"]

anglican_martyrs = ["Aaron, Lubega, Apollo, Kivebulaya, Eria, Sebukyala, Fredrick, Kizza, George, Kizza, James, Hannington, Janani, Luwum, Joseph, Balikuddembe, Kizito, Mark, Kakumba, Matia, Mulumba, Nuhu, Mbegu, Robert, Munyagayirwa, Samwiri, Mukasa, Yefusa, Namayanja, Yohana, Mukasa, Yosefu, Lugalama, Yowana, Kitaka, Yowana, Maria, Mukasa"]

new_list = list(set(catholic_martyrs))
print("\t\nList of original Catholic Martyrs names: ", catholic_martyrs)
print("\t\nList of Catholic Martyrs without duplicates: ", new_list)

new_list_2 = list(set(anglican_martyrs))
print("\t\nList of original Anglican Martyrs names: ", anglican_martyrs)
print("\t\nList of Anglican Martyrs without duplicates: ", new_list_2)

while True:
    martyr_count = input("Enter the name of the martyr: ")


    if martyr_count == 'finished':
        break

    try:
        name = str(martyr_count)
    except ValueError:
        print("Invalid")





