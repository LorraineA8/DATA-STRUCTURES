hat = [1, 2, 3, 4, 5]
Number = input("Enter number: ")
hat[2] = Number

print(hat)
del hat[-1]
print(hat)
print(len(hat))

my_list = [17, 3, 11, 5, 1, 9, 7, 15, 13]
largest = my_list[0]

for i in my_list[1:]:
    if i > largest:
        largest = i

print(largest)