#1
def greetings():
    salutions = 'Hello World'
    print(salutions)

greetings()

#2
def count():
    for i in range (1,81):
        print(i, end ='\t')
        if i % 4 ==0:
            print( )
count()
#3
def calculate():
   Fahrenheit = float(input("Enter temperature in Fahrenheit: "))
   Celsius = (Fahrenheit - 32)*5/9
   print(f"The temperature in Celsius is {Celsius:.2f} degrees.")

calculate()

def calculate():
    Celsius = float(input("Enter temperature in degrees Celsius: "))
    Fahrenheit = (Celsius * 9/5) + 32
    print(f"The temperature in fahrenheit is {Fahrenheit:.2f} degrees.")

calculate()

def get_name_and_age(name, age):
    person_info = [name, age]
    return person_info

# Example usage of the function
name = input("Enter your name: ")
age = input("Enter your age: ")

info = get_name_and_age(name, age)
print("Name and Age:", info)



