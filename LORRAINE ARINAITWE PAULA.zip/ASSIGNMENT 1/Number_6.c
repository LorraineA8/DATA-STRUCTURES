#include <stdio.h>

int main() {
    int itemNo;
    int unitPrice;
    char itemName[100];

    // User input
    printf("Enter item number: ");
    scanf("%d", &itemNo);
    printf("Enter unit price: ");
    scanf("%d", &unitPrice);
    printf("Enter item name: ");
    scanf(" %[^\n]", itemName);

    // Printing in tabular format
    printf("\n");
    printf("| Item No. | Unit Price | Item Name          |\n");
    printf("|----------|------------|--------------------|\n");
    printf("| %-8d | %-10d | %-18s |\n", itemNo, unitPrice, itemName);

    return 0;
}
