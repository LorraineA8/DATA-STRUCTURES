#include <stdio.h>
int main(){
    float r = 30, v = 4/3*3.14*r*3;
    printf("The volume of the sphere is %.0f cubic metres", v);
    

    return 0;
}