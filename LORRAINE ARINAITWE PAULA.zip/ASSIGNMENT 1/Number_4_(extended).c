#include <stdio.h>

int main(){
    float r, v;
    printf("Enter the radius of the sphere in metres(m): ");
    scanf("%f", &r);

    v = 4/3*3.14*r*3;

         printf("The volume of the sphere is %.0f cubic metres.\n", v);

     
    

    return 0;
}