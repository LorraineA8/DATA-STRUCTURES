#include <stdio.h>

int main() {
    float factory_price, vat, total_price;

    printf("Enter an amount: UGX");
    scanf("%f", &factory_price);

    vat = factory_price * 0.10;
    total_price = factory_price + vat;

    printf("With tax added:UGX %.0f \n", total_price);

    return 0;
}