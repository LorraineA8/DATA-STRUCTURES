#include <stdio.h>

int main() {
    int num, first_digit, last_digit, reversed_num, middle_number;

    while (1) {
        printf("Enter a two-digit number: ");
        scanf("%d", &num);

        if (num >= 10 && num < 100) {
            break;
        } else {
            if (num >= 100 && num < 1000 || num < 10){
                printf("You have to enter a two-digit number !!!\n");

            }
            
                    }
    }

    first_digit = num / 10;
    last_digit = num % 10;
    reversed_num = last_digit * 10 + first_digit;

    printf("The reverse is: %d\n", reversed_num);

    while(1){
        printf("Enter a three-digit number:\n");
        scanf("%d", &num);

        if(num >= 100 && num < 1000){
            break;

        }else{
            printf("You have to enter a three-digit number!!!\n");
        }
    }

    
    middle_number = num;
    last_digit = num % 10;
    num /= 10;
    first_digit = num % 10;
    reversed_num = (last_digit * 100) + (first_digit * 10) + num / 10;

     if (middle_number >= 100) {
        num /= 10;
        printf("The reverse is: %d\n", reversed_num);
    }
    return 0;
}
