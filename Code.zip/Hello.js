console.log("Hello world!🎉🎉")
//Single line comment
/*Multi line */
//defining variables; var, let, const
var fullName = "Lorraine";
//updating variables
/*

let number = 100;

//Addition assignment
number +=100
console. log(number)

//Multiplication assignment
//number *=100
//console.log(number)

//Division assignment
//number /=100
//console.log(number)

//Subtraction assignment
//number -=100
//console.log(number)

//DATA TYPES
//Primitive Data types
//Number
//Strings
//Booleans
//Symbols
//BigInt
//Null
//Undefined


//Derived Data types
/*
Arrays is a data structure in programming used to store a collection of variables/values/. 
Objects a data structure composed of both data attributes and properties
Functions is
*/
//Other data types
/*NaN rep. not a number
Infinity and -infinity
Primitive Wrappers 
*/
let country;
console.log(country)
country = "UGANDA";
console.log("This is our country", country)

let isRaining = true;
isRaining = false;
console.log(isRaining)

//Objects
const student = {

    firstName: "Jane",
    lastName: "Doe",
    age: 16,
    isResident:false,
    tuition: 234.45,
    Country: "UG"
}
console.log(student)//access everything

console.log("First name is ",student.firstName)
console.log("Last name is ",student.lastName)

//String Interpolation 
//Template Literals
//String concatenation
console.log(`The student name is ${student.firstName} ${student.lastName} and they live in ${student.Country}`)
