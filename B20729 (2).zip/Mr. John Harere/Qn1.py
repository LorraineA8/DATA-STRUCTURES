#Write a python program that mimics the backward and forward buttons on a browser using a stack(implement it as a stack)

class BrowserHistory:
    def _init_(self):
        self.stack_backward = []  # Stack for backward navigation
        self.stack_forward = []   # Stack for forward navigation
        self.current_page = None

    def open(self, url):
        if self.current_page is not None:
            self.stack_backward.append(self.current_page)
            self.stack_forward = []  # Clear the forward stack when a new page is opened
        self.current_page = url

    def backward(self):
        if self.stack_backward:
            self.stack_forward.append(self.current_page)
            self.current_page = self.stack_backward.pop()

    def forward(self):
        if self.stack_forward:
            self.stack_backward.append(self.current_page)
            self.current_page = self.stack_forward.pop()

    def current(self):
        return self.current_page

# Example usage:
browser = BrowserHistory()
browser.open("google.com")
browser.open("youtube.com")
browser.open("facebook.com")

print("Current Page:", browser.current())

browser.backward()
print("Current Page after Backward:", browser.current())

browser.forward()
print("Current Page after Forward:", browser.current())
