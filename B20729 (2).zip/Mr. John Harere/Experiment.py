# Binary search code
#Returnd the index of an occurence of target in a
def binary_search(a, target, start, stop):

    [1, 2, 3, 4, 5, 6]
    min = startmax = stop - 1

    while min <= max:
        mid = (min + max) // 2
        if a(mid) < target:
            min = mid + 1

        elif a[mid] > target:
             max = mid - 1
        else:
            return mid   #target found
        
        return - (min + 1) #target not found