#NUMBER 2: 
#Write a Python code to solve a prefix and postfix 

def evaluate_prefix(expression):
    stack = []
    operators = set(['+', '-', '*', '/'])
    
    for token in expression[::-1]:  # Process tokens in reverse order
        if token.isdigit():
            stack.append(int(token))
        elif token in operators:
            operand1 = stack.pop()
            operand2 = stack.pop()
            if token == '+':
                result = operand1 + operand2
            elif token == '-':
                result = operand1 - operand2
            elif token == '*':
                result = operand1 * operand2
            elif token == '/':
                result = operand1 / operand2
            stack.append(result)
    
    return stack[0]

# Example usage:
prefix_expression = "* + 5 4 3"
result = evaluate_prefix(prefix_expression)
print("Prefix Result:", result)

