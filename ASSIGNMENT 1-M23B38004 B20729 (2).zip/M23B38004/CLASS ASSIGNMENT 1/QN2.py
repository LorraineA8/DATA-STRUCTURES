base_length = float(input("Enter the length of the base: "))
height = float(input("Enter the height: "))

area = base_length * height

print("Length of base:", base_length)
print("Height of parallelogram:", height)
print("Area is:", area)