import math
degrees = float(input('Input vaue in degrees: '))

radians = math.radians(degrees)

print(f'{degrees} degrees in radians = {radians}')